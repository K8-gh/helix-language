Unicode true
RequestExecutionLevel admin
Name "Helix 0.9.2 (64-bit)"
OutFile "dist/Helix-Setup-0.9.2-x64.exe"
InstallDir "$PROGRAMFILES64\Helix"

!include "MUI2.nsh"
!define MUI_ABORTWARNING
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Russian"
!insertmacro MUI_LANGUAGE "English"

Section "Helix application" SEC_RUNTIME
  SetOutPath "$INSTDIR"
  File "dist\helix.exe"
  File "dist\helix-core.exe"
  SetFileAttributes "$INSTDIR\helix-core.exe" HIDDEN
  File "README.md"
  File "CHANGELOG_RU.txt"
  File "BUILDING_RU.txt"
  File "GEMINI_RECOMMENDATIONS_RU.txt"
  File "HELIX_0.9.2_GUIDE_RU.txt"
  File "HELIX_AI_INSTRUCTIONS_RU.txt"
  File "WINDOWS_TERMINAL_COMPARISON_RU.txt"
  CreateDirectory "$INSTDIR\examples"
  SetOutPath "$INSTDIR\examples"
  File "examples\hello.hlx"
  File "examples\app.hlx"
  File "examples\desktop_app.hlx"
  File "examples\button_app.hlx"
  File "examples\calculator.hlx"
  File "examples\standard_library.hlx"
  File "examples\hardware.hlx"
  File "examples\gemini_level3.hlx"
  File "examples\filesystem.hlx"
  File "examples\time_random.hlx"
  SetOutPath "$INSTDIR"

  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS\Helix"
  Delete "$SMPROGRAMS\Helix\Helix Terminal.lnk"
  Delete "$INSTDIR\helix-terminal.exe"
  CreateShortcut "$SMPROGRAMS\Helix\Helix.lnk" "$INSTDIR\helix.exe"
  CreateShortcut "$SMPROGRAMS\Helix\Examples.lnk" "$WINDIR\explorer.exe" '"$INSTDIR\examples"'
  CreateShortcut "$SMPROGRAMS\Helix\Uninstall Helix.lnk" "$INSTDIR\Uninstall.exe"

  ReadRegStr $0 HKCU "Software\Classes\.hlx" ""
  StrCmp $0 "Helix.Source" skipBackup
  ReadRegStr $0 HKCU "Software\Helix\Backup" "HadPreviousHlx"
  StrCmp $0 "" saveBackup skipBackup
saveBackup:
  ReadRegStr $0 HKCU "Software\Classes\.hlx" ""
  StrCmp $0 "" noPreviousAssociation
  WriteRegStr HKCU "Software\Helix\Backup" "PreviousHlx" "$0"
  WriteRegStr HKCU "Software\Helix\Backup" "HadPreviousHlx" "1"
  Goto associationReady
noPreviousAssociation:
  WriteRegStr HKCU "Software\Helix\Backup" "HadPreviousHlx" "0"
associationReady:
skipBackup:
  WriteRegStr HKCU "Software\Classes\.hlx" "" "Helix.Source"
  WriteRegStr HKCU "Software\Classes\Helix.Source" "" "Helix source file"
  WriteRegStr HKCU "Software\Classes\Helix.Source\DefaultIcon" "" '"$INSTDIR\helix.exe",0'
  WriteRegStr HKCU "Software\Classes\Helix.Source\shell\open\command" "" '"$INSTDIR\helix.exe" "%1"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Helix" "DisplayName" "Helix 0.9.2 (64-bit)"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Helix" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Helix" "InstallLocation" "$INSTDIR"
SectionEnd

Section "Uninstall"
  DeleteRegKey HKCU "Software\Classes\Helix.Source"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\Helix"
  ReadRegStr $2 HKCU "Software\Classes\.hlx" ""
  StrCmp $2 "Helix.Source" 0 associationRestored
  ReadRegStr $0 HKCU "Software\Helix\Backup" "HadPreviousHlx"
  StrCmp $0 "1" restoreAssociation removeHelixAssociation
restoreAssociation:
  ReadRegStr $1 HKCU "Software\Helix\Backup" "PreviousHlx"
  WriteRegStr HKCU "Software\Classes\.hlx" "" "$1"
  Goto associationRestored
removeHelixAssociation:
  DeleteRegValue HKCU "Software\Classes\.hlx" ""
associationRestored:
  DeleteRegKey HKCU "Software\Helix\Backup"
  Delete "$SMPROGRAMS\Helix\Helix.lnk"
  Delete "$SMPROGRAMS\Helix\Examples.lnk"
  Delete "$SMPROGRAMS\Helix\Uninstall Helix.lnk"
  RMDir "$SMPROGRAMS\Helix"
  RMDir /r "$INSTDIR"
SectionEnd
