#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS_DIR="${HELIX_APPIMAGE_TOOLS:-/tmp/helix-appimage-tools}"
APPDIR="$ROOT/dist/Helix.AppDir"
OUTPUT="$ROOT/dist/Helix-0.9.2-x86_64.AppImage"
mkdir -p "$TOOLS_DIR" "$ROOT/dist"

APPIMAGETOOL="$TOOLS_DIR/appimagetool-x86_64.AppImage"
LINUXDEPLOY="$TOOLS_DIR/linuxdeploy-x86_64.AppImage"
GTK_PLUGIN="$TOOLS_DIR/linuxdeploy-plugin-gtk"

fetch_tool() {
    local url="$1" destination="$2"
    if [[ ! -x "$destination" ]]; then
        curl -fL --retry 3 --retry-delay 2 "$url" -o "$destination"
        chmod +x "$destination"
    fi
}

# Official AppImage project tools; GTK deployment plugin is distributed by linuxdeploy.
fetch_tool "https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage" "$APPIMAGETOOL"
fetch_tool "https://github.com/linuxdeploy/linuxdeploy/releases/download/1-alpha-20251107-1/linuxdeploy-x86_64.AppImage" "$LINUXDEPLOY"
if [[ ! -x "$GTK_PLUGIN" ]]; then
    curl -fL --retry 3 --retry-delay 2 \
      "https://raw.githubusercontent.com/linuxdeploy/linuxdeploy-plugin-gtk/master/linuxdeploy-plugin-gtk.sh" \
      -o "$GTK_PLUGIN"
    chmod +x "$GTK_PLUGIN"
fi

command -v nasm >/dev/null || { echo 'Missing build dependency: nasm' >&2; exit 1; }
command -v gcc >/dev/null || { echo 'Missing build dependency: gcc' >&2; exit 1; }
command -v pkg-config >/dev/null || { echo 'Missing build dependency: pkg-config' >&2; exit 1; }
pkg-config --exists gtk+-3.0 || { echo 'Missing build dependency: libgtk-3-dev' >&2; exit 1; }

# The language engine remains NASM. GTK is only the Linux desktop/terminal host.
nasm -f elf64 "$ROOT/src/helix.asm" -o "$ROOT/dist/helix-linux-x86_64.o"
gcc -no-pie "$ROOT/dist/helix-linux-x86_64.o" -o "$ROOT/dist/helix-linux-x86_64"
gcc -std=c11 -O2 -Wall -Wextra -Wpedantic \
  $(pkg-config --cflags gtk+-3.0) \
  "$ROOT/src/helix_terminal_linux.c" -o "$ROOT/dist/helix-terminal-linux" \
  $(pkg-config --libs gtk+-3.0)

rm -rf "$APPDIR"
mkdir -p "$APPDIR/usr/bin" "$APPDIR/usr/share/helix/examples" "$APPDIR/usr/share/doc/helix"
cp "$ROOT/dist/helix-linux-x86_64" "$APPDIR/usr/bin/helix-linux-x86_64"
cp "$ROOT/dist/helix-terminal-linux" "$APPDIR/usr/bin/helix-terminal-linux"
cp "$ROOT/packaging/appimage/AppRun" "$APPDIR/AppRun"
cp "$ROOT/packaging/appimage/helix.desktop" "$APPDIR/helix.desktop"
cp "$ROOT/packaging/appimage/helix.svg" "$APPDIR/helix.svg"
cp "$ROOT/examples/"*.hlx "$APPDIR/usr/share/helix/examples/"
cp "$ROOT/README.md" "$ROOT/CHANGELOG_RU.txt" "$ROOT/BUILDING_RU.txt" "$ROOT/GEMINI_RECOMMENDATIONS_RU.txt" "$ROOT/HELIX_0.9.2_GUIDE_RU.txt" "$ROOT/HELIX_AI_INSTRUCTIONS_RU.txt" "$APPDIR/usr/share/doc/helix/"
chmod +x "$APPDIR/AppRun"

# Bundle GTK libraries, GTK modules, GLib schemas, and pixbuf resources.
export PATH="$TOOLS_DIR:$PATH"
export ARCH=x86_64
"$LINUXDEPLOY" --appdir "$APPDIR" \
  --executable "$APPDIR/usr/bin/helix-terminal-linux" \
  --executable "$APPDIR/usr/bin/helix-linux-x86_64" \
  --desktop-file "$APPDIR/helix.desktop" \
  --icon-file "$APPDIR/helix.svg" \
  --plugin gtk

rm -f "$OUTPUT"
ARCH=x86_64 "$APPIMAGETOOL" "$APPDIR" "$OUTPUT"
chmod +x "$OUTPUT"
echo "Created $OUTPUT"
